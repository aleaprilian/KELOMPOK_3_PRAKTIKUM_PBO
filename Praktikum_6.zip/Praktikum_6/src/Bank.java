public class Bank {
    private int saldo;
    static String namaBank = "BRI";

    public static void tampilNamaBank() {
        System.out.println("Nama Bank : " + namaBank);
    }

    Bank(int saldo){
        this.saldo = saldo;
    }
    public int getSaldo(){
        return saldo;
    }
}
