public class Produk {
    public String nama;
    private double harga;
    protected int stok;
    private String namaSupplier = "Alex";

    static int jumlahProduk = 0;
    public Produk(String nama,double harga,int stok){
            this.nama = nama;
            this.harga = harga;
            this.stok = stok;
    }

    public String getNama(){
        return this.nama;
    }

    private void tampilNamaSupplier(){
        System.out.println("Nama Supplier : "  + nama);
    }

    public void namaSupplierFix(){
        tampilNamaSupplier();
    }

    public String setNamaSupplier(String namaSupplier) {
        return this.namaSupplier = namaSupplier;

    }
//        void tampilNamaSupplier(){
//           System.out.println("Nama Supplier : " + namaSupplier);
//        }


    }
