//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.






        //bank
       // Bank bank1 = new Bank("Ale",250000000);
//        System.out.println("Nama Anda : " + bank1.getNamaNasabah());
//        bank1.setNamaNasabah("Septian");
//        System.out.println("Nama Anda : " + bank1.getNamaNasabah());**
//        bank1.getNamaNasabah();
//        bank1.setSaldo(3000000);
//        System.out.println("Saldo Anda : " + bank1.getSaldo());


        Rekening rek = new Rekening("Ale", 2500000);
        System.out.println("Nama Nasabah : " + rek.namaNasabah);
        //rek.setNamaNasabah("Septian");
        //System.out.println(rek.getNamaNasabah());
        rek.setSaldo(300000);
        System.out.println(rek.getSaldo());


        Bank.tampilNamaBank();
        Bank bank1 = new Bank(50000);
        System.out.print("Saldo Minimum Akun Bank : " + bank1.getSaldo());
    }
}